import importerReducers from 'src/modules/shared/importer/importerReducers';
import actions from 'src/modules/treatment/importer/treatmentImporterActions';

export default importerReducers(actions);
