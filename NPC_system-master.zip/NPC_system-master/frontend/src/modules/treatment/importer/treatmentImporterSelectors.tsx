import importerSelectors from 'src/modules/shared/importer/importerSelectors';

const treatmentImporterSelectors = importerSelectors(
  'treatment.importer',
);

export default treatmentImporterSelectors;
