import importerReducers from 'src/modules/shared/importer/importerReducers';
import actions from 'src/modules/user/importer/userImporterActions';

export default importerReducers(actions);
