import importerSelectors from 'src/modules/shared/importer/importerSelectors';

const userImporterSelectors = importerSelectors('user.importer');
export default userImporterSelectors;
