const vitalSignEnumerators = {

};

export default vitalSignEnumerators;
