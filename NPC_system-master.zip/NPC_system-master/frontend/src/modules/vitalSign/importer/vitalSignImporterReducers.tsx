import importerReducers from 'src/modules/shared/importer/importerReducers';
import actions from 'src/modules/vitalSign/importer/vitalSignImporterActions';

export default importerReducers(actions);
