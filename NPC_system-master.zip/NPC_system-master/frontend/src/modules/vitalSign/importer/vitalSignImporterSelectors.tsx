import importerSelectors from 'src/modules/shared/importer/importerSelectors';

const vitalSignImporterSelectors = importerSelectors(
  'vitalSign.importer',
);

export default vitalSignImporterSelectors;
