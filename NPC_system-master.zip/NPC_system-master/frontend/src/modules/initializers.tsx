import authInitializer from 'src/modules/auth/authInitializer';

export default [authInitializer];
