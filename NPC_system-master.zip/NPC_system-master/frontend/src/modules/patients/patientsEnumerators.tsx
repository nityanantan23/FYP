const patientsEnumerators = {

};

export default patientsEnumerators;
