import importerSelectors from 'src/modules/shared/importer/importerSelectors';

const patientsImporterSelectors = importerSelectors(
  'patients.importer',
);

export default patientsImporterSelectors;
