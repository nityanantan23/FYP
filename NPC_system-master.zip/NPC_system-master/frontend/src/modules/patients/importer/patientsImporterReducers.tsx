import importerReducers from 'src/modules/shared/importer/importerReducers';
import actions from 'src/modules/patients/importer/patientsImporterActions';

export default importerReducers(actions);
