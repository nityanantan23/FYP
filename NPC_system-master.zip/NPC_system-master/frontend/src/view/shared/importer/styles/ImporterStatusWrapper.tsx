import styled from 'styled-components';

const ImporterStatusWrapper = styled.div`
  margin-top: -16px;
  margin-bottom: 24px;
`;

export default ImporterStatusWrapper;
