import styled from 'styled-components';

const OtherActions = styled.div`
  margin-top: 36px;
  text-align: center;
`;

export default OtherActions;
