export interface IRepositoryOptions {
  language: string;
  currentUser: any;
  currentTenant: any;
  database: any;
  transaction?: any;
  bypassPermissionValidation?: any;
}
