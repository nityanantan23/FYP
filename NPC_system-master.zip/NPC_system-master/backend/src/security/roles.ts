
class Roles {
  static get values() {
    return {
      admin: 'admin',
      custom: 'custom',
    };
  }
}

export default Roles;
