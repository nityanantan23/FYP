import pandas as pd
from fastapi import FastAPI
from pycaret.classification import load_model, predict_model
import uvicorn
from fastapi.middleware.cors import CORSMiddleware

# Create the app
app = FastAPI()

origins = [
    "http://localhost.tiangolo.com",
    "https://localhost.tiangolo.com",
    "http://localhost",
    "http://localhost:8080",
    "127.0.0.1:33284"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# Load trained Pipeline
model = load_model('rf')

@app.get("/")
def hello():
    return {"message":"Hello , this is the NPC cancer API...u can go to /docs or /predict"}
# Define predict function
@app.post('/predict')
def predict(AGE_AT_POSITIVE, Sex, State, Smoking, Alcohol, Diabetes, Hypertension, OtherCancer, FamilyCancer, Stage, NPC, FirstPositiveBiopsyInHPE, WHO_Grade, RT_TreatmentIntent, RT_Modality, RT_Dose_GY, RT_Fractions, RT_ConcurrentChemo, RT_CompletedConcChemo_STD, RT_Completed_STD, RT_Duration, RT_Started_After, CT_Intent, CT_Drug, CT_TotalCyclesGiven, CT_Completed_STD, CT_Duration, Average_SPO2, Average_Resting_Heart_Rate, Average_step_count, Average_BP_Systolic):
    data = pd.DataFrame([[AGE_AT_POSITIVE, Sex, State, Smoking, Alcohol, Diabetes, Hypertension, OtherCancer, FamilyCancer, Stage, NPC, FirstPositiveBiopsyInHPE, WHO_Grade, RT_TreatmentIntent, RT_Modality, RT_Dose_GY, RT_Fractions, RT_ConcurrentChemo, RT_CompletedConcChemo_STD, RT_Completed_STD, RT_Duration, RT_Started_After, CT_Intent, CT_Drug, CT_TotalCyclesGiven, CT_Completed_STD, CT_Duration, Average_SPO2, Average_Resting_Heart_Rate, Average_step_count, Average_BP_Systolic]])
    data.columns = ['AGE_AT_POSITIVE', 'Sex', 'State', 'Smoking', 'Alcohol', 'Diabetes', 'Hypertension', 'OtherCancer', 'FamilyCancer', 'Stage', 'NPC', 'FirstPositiveBiopsyInHPE', 'WHO_Grade', 'RT_TreatmentIntent', 'RT_Modality', 'RT_Dose_GY', 'RT_Fractions', 'RT_ConcurrentChemo', 'RT_CompletedConcChemo_STD', 'RT_Completed_STD', 'RT_Duration', 'RT_Started_After', 'CT_Intent', 'CT_Drug', 'CT_TotalCyclesGiven', 'CT_Completed_STD', 'CT_Duration', 'Average_SPO2', 'Average_Resting_Heart_Rate', 'Average_step_count', 'Average_BP_Systolic']
    predictions = predict_model(model, data=data)
    print(": lr_api.py ~ line 14 ~ data", list(predictions['Label']))
    # if list(predictions['Label'])[0] > 0.5 :
    #     return {'prediction': "yes"}
    # return {'prediction': "no"}
    return list(predictions['Label'])[0]
if __name__ == '__main__':
    uvicorn.run(app, port=8081, host='0.0.0.0')








    